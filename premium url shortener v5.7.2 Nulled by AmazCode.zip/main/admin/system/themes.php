<?php if(!defined("APP")) die()?>
<p class="alert alert-info">
  All themes are located in the "themes" folder. All you have to do is to upload your theme in that folder then come here to activate it. Make sure to name your main stylesheet style.css otherwise the theme will not show up!
</p>      
<div class="row themes">
  <?php echo $theme_list ?> 
</div>